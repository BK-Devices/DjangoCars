function createRequestObject() {
    var xmlhttp;
    if(window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    else if(window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhttp;
}
var http = createRequestObject();

const date = new Date();
document.getElementById("date").innerHTML = "Today : " + date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear();

model = document.getElementById("model");
company = document.getElementById("company");
type = document.getElementById("type");
function changeSearchType(value){
    if(value == "all"){
        model.disabled = true;
        company.disabled = true;
        type.disabled = true;

        model.style.display = "none";
        company.style.display = "none";
        type.style.display = "none";
    }
    else if(value == "model"){
        model.disabled = false;
        company.disabled = true;
        type.disabled = true;

        model.style.display = "block";
        company.style.display = "none";
        type.style.display = "none";
    }
    else if(value == "company"){
        model.disabled = true;
        company.disabled = false;
        type.disabled = true;

        model.style.display = "none";
        company.style.display = "block";
        type.style.display = "none";
    }
    else if(value == "type"){
        model.disabled = true;
        company.disabled = true;
        type.disabled = false;

        model.style.display = "none";
        company.style.display = "none";
        type.style.display = "block";
    }
}

car_mess = document.getElementById("car-mess");
function searchCars(){
    event.preventDefault();
    typ = document.getElementById("ser-typ").value;
    if(typ == "all"){
        value = "all"
    }
    else if(typ == "model"){
        value = model.value;
    }
    else if(typ == "company"){
        value = company.value;
    }
    else if(typ == "type"){
        value = type.value;
    }
    http.open("get", "/searchcar/?type=" + typ + "&name=" + value);
    http.onreadystatechange = searchCarsResponse;
    http.send(null);
}
function searchCarsResponse(){
    if(http.readyState == 4){
        result = JSON.parse(http.responseText).cars;
        car_mess.style.display = "block";
        if(result == "no cars"){
            car_mess.innerHTML = "Sorry! Their are no cars in our Showroom";
        }
        else if(result == "error"){
            car_mess.innerHTML = "Sorry Connection Error";
        }
        else{
            document.getElementById("ser-car").style.display = "none";
            document.getElementById("ser-res").style.display = "block";
            showCars(result);
        }
    }
}
function showCars(val){
    if(val == "inc"){
        car += 1;
    }
    else if(val == "dec"){
        car -= 1;
    }
    else{
        result = val;
        car = 0;
    }
    len = Object.keys(result).length;
    if(car > len - 1){
        car = len - 1;
    }
    if(car < 0){
        car = 0;
    }
    document.getElementById("car-num").innerHTML  = (car + 1) + " / " + len;
    document.getElementById("pho").src = result[car].Photo;

    details = "Model : " + result[car].Model + "<br><br>Company : " + result[car].Company +
              "<br><br>Type : " + result[car].Type + "<br><br>Engine : " + result[car].Engine +
              "<br><br>Mileage : " + result[car].Mileage + "<br><br>Transmission : " + result[car].Transmission +
              "<br><br>Fuel Type : " + result[car].Fuel + "<br><br>Price : " + result[car].Price;
    document.getElementById("div2").innerHTML = details;
}

var in_mess = document.getElementById("in-mess");
function signIn(){
    event.preventDefault();
    id = document.getElementById("in-id").value;
    psw = document.getElementById("in-psw").value;
    http.open("get", "/signin/?id=" + id + "&psw=" + psw);
    http.onreadystatechange = signInResponse;
    http.send(null);
}
function signInResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        in_mess.style.display = "block";
        in_mess.style.color = "#f00";
        if(response == "success"){
            document.getElementById("signin").action = "/user/";
            document.getElementById("signin").submit();
        }
        else if(response == "failed"){
            in_mess.innerHTML = "Please check your userid or password";
        }
        else{
            in_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

function block(value){
    var home = document.getElementById("home").style;
    var search = document.getElementById("search").style;
    var sign = document.getElementById("sign").style;

    var home_li = document.getElementById("home-li");
    var search_li = document.getElementById("search-li");
    var sign_li = document.getElementById("sign-li");

    if(value == 'home'){
        home.display = "block";
        sign.display = search.display = "none";
        
        home_li.style = "background: #18173a; color: #fff;";
        sign_li.style = search_li.style = "background: transparent; color: #18173a;";
    }
    else if(value == 'search'){
        search.display = "block";
        home.display = sign.display = "none";

        search_li.style = "background: #18173a; color: #fff;";
        home_li.style = sign_li.style = "background: transparent; color: #18173a;";

        car_mess.style.display = "none";
        document.getElementById("car-search").reset();
        document.getElementById("ser-car").style.display = "block";
        document.getElementById("ser-res").style.display = "none";
    }
    else if(value == 'sign'){
        sign.display = "block";
        home.display = search.display = "none";

        sign_li.style = "background: #18173a; color: #fff;";
        home_li.style = search_li.style = "background: transparent; color: #18173a;";

        document.getElementById("signin").reset();
        in_mess.style.display = "none";
    }
}