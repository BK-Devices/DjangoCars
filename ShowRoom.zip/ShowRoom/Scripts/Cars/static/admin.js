function createRequestObject() {
    var xmlhttp;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhttp;
}
var http = createRequestObject();

model = document.getElementById("model");
company = document.getElementById("company");
type = document.getElementById("type");
function changeSearchType(value){
    if(value == "all"){
        model.disabled = true;
        company.disabled = true;
        type.disabled = true;

        model.style.display = "none";
        company.style.display = "none";
        type.style.display = "none";
    }
    else if(value == "model"){
        model.disabled = false;
        company.disabled = true;
        type.disabled = true;

        model.style.display = "block";
        company.style.display = "none";
        type.style.display = "none";
    }
    else if(value == "company"){
        model.disabled = true;
        company.disabled = false;
        type.disabled = true;

        model.style.display = "none";
        company.style.display = "block";
        type.style.display = "none";
    }
    else if(value == "type"){
        model.disabled = true;
        company.disabled = true;
        type.disabled = false;

        model.style.display = "none";
        company.style.display = "none";
        type.style.display = "block";
    }
}

car_mess = document.getElementById("car-mess");
function searchCars(){
    event.preventDefault();
    typ = document.getElementById("ser-typ").value;
    if(typ == "all"){
        value = "all"
    }
    else if(typ == "model"){
        value = model.value;
    }
    else if(typ == "company"){
        value = company.value;
    }
    else if(typ == "type"){
        value = type.value;
    }
    http.open("get", "/searchcar/?type=" + typ + "&name=" + value);
    http.onreadystatechange = searchCarsResponse;
    http.send(null);
}
function searchCarsResponse(){
    if(http.readyState == 4){
        result = JSON.parse(http.responseText).cars;
        car_mess.style.display = "block";
        if(result == "no cars"){
            car_mess.innerHTML = "Sorry! Their are no cars in our Showroom";
        }
        else if(result == "error"){
            car_mess.innerHTML = "Sorry Connection Error";
        }
        else{
            document.getElementById("ser-car").style.display = "none";
            document.getElementById("ser-res").style.display = "block";
            showCars(result);
        }
    }
}
function showCars(val){
    if(val == "inc"){
        car += 1;
    }
    else if(val == "dec"){
        car -= 1;
    }
    else{
        result = val;
        car = 0;
    }
    len = Object.keys(result).length;
    if(car > len - 1){
        car = len - 1;
    }
    if(car < 0){
        car = 0;
    }
    document.getElementById("car-num").innerHTML  = (car + 1) + " / " + len;
    document.getElementById("pho").src = result[car].Photo;

    details = "Model : " + result[car].Model + "<br><br>Company : " + result[car].Company +
              "<br><br>Type : " + result[car].Type + "<br><br>Engine : " + result[car].Engine +
              "<br><br>Mileage : " + result[car].Mileage + "<br><br>Transmission : " + result[car].Transmission +
              "<br><br>Fuel Type : " + result[car].Fuel + "<br><br>Price : " + result[car].Price;
    document.getElementById("div2").innerHTML = details;
}

newcar_mess = document.getElementById("newcar-mess");
newcust_mess = document.getElementById("newcust-mess");
editcar_mess = document.getElementById("wditcar-mess");
function changeAddType(value){
    if(value == "new-car"){
        document.getElementById("new-car").style.display = "block";
        document.getElementById("new-cust").style.display = "none";
        document.getElementById("edit-car").style.display = "none";

        newcar_mess.style.display = "none";
        document.getElementById("new-car").reset();
    }
    else if(value == "new-cust"){
        document.getElementById("new-car").style.display = "none";
        document.getElementById("new-cust").style.display = "block";
        document.getElementById("edit-car").style.display = "none";

        newcust_mess.style.display = "none";
        document.getElementById("new-cust").reset();
    }
    else if(value == "edit-car"){
        document.getElementById("new-car").style.display = "none";
        document.getElementById("new-cust").style.display = "none";
        document.getElementById("edit-car").style.display = "block";

        editcar_mess.style.display = "none";
        document.getElementById("edit-car").reset();
    }
}

function newCar(){
    event.preventDefault();
    mod = document.getElementById("mod").value;
    comp = document.getElementById("comp").value;
    typ = document.getElementById("typ").value;
    eng = document.getElementById("eng").value + " cc";
    mil = document.getElementById("mil").value + " km/l";
    tran = document.getElementById("tran").value;
    fuel = document.getElementById("ful").value;
    pho = document.getElementById("img").value;
    pri = document.getElementById("pri").value + " " + document.getElementById("prity").value;

    http.open("get", "/newcar/?mod=" + mod + "&comp=" + comp + "&typ" + typ + "&eng=" + eng + "&mil=" + mil,
                                    "&tran=" + tran + "&fuel=" + fuel + "&pho=" + pho + "&pri=" + pri);
    http.onreadystatechange = newCarResponse;
    http.send(null);
}
function newCarResponse(){
    if(http.readyState == 4){
        result = http.responseText;
        newcar_mess.style.display = "block";
        newcar_mess.style.color = "#f00";
        if(result == "found"){
            newcar_mess.innerHTML = "Car is already Registered";
        }
        else if(result == "symbolerror"){
            newcar_mess.innerHTML = "Please provide data without '&'";
        }
        else if(result == "error"){
            newcar_mess.innerHTML = "Sorry! Connection Error";
        }
        else if(result == "success"){
            newcar_mess.style.color = "#0f0";
            newcar_mess.innerHTML = "New Car added Successfully";
        }
    }
}

function editCar(){
    event.preventDefault();
    mod = document.getElementById("edit-mod").value;
    pri = document.getElementById("edit-pri").value + " " + document.getElementById("edit-prity").value;

    http.open("get", "/editcar/?mod=" + mod + "&pri=" + pri);
    http.onreadystatechange = editCarResponse;
    http.send(null);
}
function editCarResponse(){
    if(http.readyState == 4){
        result = JSON.parse(http.responseText);
        editcar_mess.style.display = "block";
        editcar_mess.style.color = "f00";
        if(result == "no car"){
            editcar_mess.innerHTML = "Sorry! Car Not Found";
        }
        else if(result == "error"){
            editcar_mess.innerHTML = "Sorry! Connection Error";
        }
        else if(result == "success"){
            editcar_mess.style.color = "0f0";
            editcar_mess.innerHTML = "Car Price chage successfully";
        }
    }
}

function newCust(){
    event.preventDefault();
    nm = document.getElementById("cust-nm").value;
    em = document.getElementById("cust-em").value;
    mob = document.getElementById("cust-mo").value;
    dt = document.getElementById("cust-dt").value;
    car = document.getElementById("cust-car").value;
    add = document.getElementById("cust-ad").value;

    http.open("get", "/newcust/?nm=" + nm + "&em=" + em + "&mo=" + mob + "&dt=" + dt + "&car=" + car + "&add=" + add);
    http.onreadystatechange = newCustResponse;
    http.send(null);
}
function newCustResponse(){
    if(http.readyState == 4){
        result = http.responseText;
        newcust_mess.style.display = "block";
        newcust_mess.style.color = "#f00";
        if(result == "error"){
            newcust_mess.innerHTML = "Sorry! Connection Error";
        }
        else if(result == "success"){
            newcust_mess.style.color = "#0f0";
            newcust_mess.innerHTML = "New Customer added Successfully";
        }
    }
}


cust_mess = document.getElementById("cust-mess");
function searchCust(){
    http.open("get", "/searchcust/?type=all&name=all");
    http.onreadystatechange = searchCustResponse;
    http.send(null);
}
function searchCustResponse(){
    if(http.readyState == 4){
        result = JSON.parse(http.responseText).customers;

        if(result == "error"){
            cust_mess.innerHTML = "Sorry! Connection Error";
        }
        else if(result == "no customer"){
            cust_mess.innerHTML = "Sorry! Their are no customers";
        }
        else{
            data = "<br>";
            len = Object.keys(result).length;
            for(let i = 0; i < len; i++) {
                data += ("<b>Id : " + result[i].Id + "</b>");
                data += ("<br>Name : " + result[i].Name);
                data += ("<br>Email : " + result[i].Email);
                data += ("<br>Mobile : " + result[i].Mobile);
                data += ("<br>Date : " + result[i].Date);
                data += ("<br>Car : " + result[i].Car);
                data += ("<br>Address : " + result[i].Address + "<br><br><br>");
            }
            cust_mess.innerHTML = data;
        }
    }
}

google.charts.load('current', {'packages':['corechart']});
function searchReport(typ){
    http.open("get", "/carreport/?type=" + typ);
    http.onreadystatechange = reportResponse;
    http.send(null);
}
function reportResponse(){
    if(http.readyState == 4){
        result = JSON.parse(http.responseText).report;
        document.getElementById("piechart").style.display = "block";
        if(result == "error"){
            document.getElementById("piechart").innerHTML = "Sorry! Connection Error";
        }
        else{
            var data = google.visualization.arrayToDataTable(result);
            var options = {
                title: "Searching Report",
                pieSliceText: 'percentage',
            };
            var chart = new google.visualization.PieChart(document.getElementById('piechart'));
            chart.draw(data, options);
        }
    }
}

function block(value){
    var home = document.getElementById("home").style;
    var action = document.getElementById("action").style;
    var cust = document.getElementById("cust").style;
    var report = document.getElementById("report").style;

    var home_li = document.getElementById("home-li");
    var action_li = document.getElementById("action-li");
    var cust_li = document.getElementById("cust-li");
    var report_li = document.getElementById("report-li");

    if(value == 'home'){
        home.display = "block";
        action.display = cust.display = report.display = "none";
        
        home_li.style = "background: #18173a; color: #fff;";
        action_li.style = cust_li.style = report_li.style = "background: transparent; color: #18173a;";

        car_mess.style.display = "none";
        document.getElementById("car-search").reset();
        document.getElementById("ser-car").style.display = "block";
        document.getElementById("ser-res").style.display = "none";
    }
    else if(value == 'action'){
        action.display = "block";
        home.display = cust.display = report.display = "none";

        action_li.style = "background: #18173a; color: #fff;";
        home_li.style = cust_li.style = report_li.style = "background: transparent; color: #18173a;";

        document.getElementById("new-car").style.display = "none";
        document.getElementById("new-cust").style.display = "none";
        document.getElementById("edit-car").style.display = "none";

        document.getElementById("action-type").reset();
    }
    else if(value == 'cust'){
        cust.display = "block";
        home.display = action.display = report.display = "none";

        cust_li.style = "background: #18173a; color: #fff;";
        home_li.style = action_li.style = report_li.style = "background: transparent; color: #18173a;";

        searchCust();
    }
    else if(value == 'report'){
        report.display = "block";
        home.display = action.display = cust.display = "none";

        report_li.style = "background: #18173a; color: #fff;";
        home_li.style = action_li.style = cust_li.style = "background: transparent; color: #18173a;";

        document.getElementById("search-report").reset();
        document.getElementById("piechart").style.display = "none";
    }
}