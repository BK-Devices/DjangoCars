from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from .models import *

def index(request):
    return render(request, 'index.html')

def admin(request):
    try:
        user = request.session.get('user')
        if user == 'Admin': return render(request, 'admin.html')
        else: return render(request, 'index.html')
    except: return render(request, 'index.html')


def signIn(request):
    mess = None
    if request.method == "GET":
        try:
            id = request.GET['id']
            psw = request.GET['psw']
            if id == 'Admin' and psw == 'Admin@1234':
                mess = 'success'
                request.session['user'] = 'Admin'
            else: mess = 'failed'
        except: mess = 'error'
    return HttpResponse(mess)

def signOut(request):
    try: del request.session['user']
    except: pass
    return render(request, 'index.html')


def searchCar(request):
    result = None
    if request.method == "GET":
        try:
            type = request.GET['type']
            name = request.GET['name']
            result = cars().searchCar(type, name)
        except: result = 'error'
    return JsonResponse({'cars': result})

def searchCust(request):
    result = None
    if request.method == "GET":
        try:
            ty = request.GET['type']
            nm = request.GET['name']
            result = customers().searchCust(ty, nm)
        except: result = 'error'
    return JsonResponse({'customers': result})

def carReport(request):
    result = None
    if request.method == "GET":
        try:
            ty = request.GET['type']
            result = report().showReport(ty)
        except: result = 'error'
    return JsonResponse({'report': result})


def newCar(request):
    mess = None
    if request.method == "GET":
        try:
            mod = request.GET['mod']
            comp = request.GET['comp']
            typ = request.GET['typ']
            eng = request.GET['eng']
            mil = request.GET['mil']
            tran = request.GET['tran']
            ful = request.GET['fuel']
            pho = request.GET['pho']
            pri = request.GET['pri']
            mess = cars().newCar(mod, comp, typ, eng, mil, tran, ful, pho, pri)
        except: mess = 'symbolerror'
    return HttpResponse(mess)

def newCust(request):
    mess = None
    if request.method == "GET":
        try:
            nm = request.GET['nm']
            em = request.GET['em']
            mo = request.GET['mo']
            dt = request.GET['dt']
            car = request.GET['car']
            add = request.GET['add']
            mess = customers().newCust(nm, em, mo, dt, car, add)
        except: mess = 'error'
    return HttpResponse(mess)


def editCar(request):
    mess = None
    if request.method == "GET":
        try:
            mod = request.GET['mod']
            pri = request.GET['pri']
            mess = cars().editCar(mod, pri)
        except: mess = 'error'
    return HttpResponse(mess)

